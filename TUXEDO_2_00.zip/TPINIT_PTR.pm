package TPINIT_PTR; 
@ISA = qw(CHAR_PTR);
1;
