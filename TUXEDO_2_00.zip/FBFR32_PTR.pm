package FBFR32_PTR; 
@ISA = qw(CHAR_PTR);
1;
